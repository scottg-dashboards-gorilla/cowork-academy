# Business brief: Saltwater Stays (sample)

- What we do: manage 12 vacation rental homes for their owners, from guest bookings to cleaning and repairs.
- Who we serve: families and small groups on beach and lake holidays, and the property owners who trust us with their homes.
- Tone: warm, clear and professional. Short sentences. No hype.
- Never: promise refunds, discounts or early check-in without approval; share guest contact details.
