Cowork Academy starter folder
=============================
Everything here is made up for practice: a fictional company with 12 rental homes, April to September 2026.
Point Claude Cowork at this folder and every mission's files are ready.

bookings.csv            One row per booking. total_revenue is after the platform fee (rent + cleaning fee - platform fee). Cancelled bookings show 0 revenue.
guest-reviews.csv       Guest reviews linked to bookings, with a 1 to 5 rating.
maintenance-tickets.csv Repair tickets with category, vendor, cost and status. Tickets still open on 30 September 2026 show status Open.
owner-statement-driftwood-july-2026.csv  A practice owner statement (management fee is 20% of rent). It contains mistakes on purpose.
guest-messages.txt      A practice guest inbox.
team-notes.txt          A practice email thread about a broken hot tub.
sample-business-brief.md  A sample company brief to use if you don't want to write your own.
