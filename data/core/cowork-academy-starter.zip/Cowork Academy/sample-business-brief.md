# Business brief: Lakeview Supply Co. (sample)

- What we do: supply offices, clinics and schools with everyday supplies, furniture, tech accessories and cleaning products, plus service plans that keep their equipment running.
- Who we serve: about 30 business customers in four regions (North, South, East and West), from small offices to multi-site clinics.
- Team: about 140 people across sales, customer support, operations and the warehouse, finance and HR.
- Tone: friendly, clear and practical. Short sentences. No jargon or hype.
- Never: promise discounts, credits or delivery dates without approval; share one customer's details with another.
